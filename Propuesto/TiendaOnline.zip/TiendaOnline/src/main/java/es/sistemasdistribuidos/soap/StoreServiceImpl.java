package es.sistemasdistribuidos.soap;

import es.sistemasdistribuidos.model.Product;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.List;

@WebService(endpointInterface = "es.sistemasdistribuidos.soap.StoreService")
public class StoreServiceImpl implements StoreService {

    private static List<Product> products = new ArrayList<>();

    static {
        products.add(new Product("001", "Laptop Lenovo", 2500.00));
        products.add(new Product("002", "Mouse Logitech", 150.00));
        products.add(new Product("003", "Teclado Mecánico", 300.00));
        products.add(new Product("004", "Monitor 24\"", 850.00));
        products.add(new Product("005", "Auriculares", 220.00));
        products.add(new Product("006", "Disco SSD 512GB", 400.00));
    }

    @Override
    public List<Product> getProducts() {
        return products;
    }

    @Override
    public void addProduct(Product product) {
        products.add(product);
    }

    @Override
    public String buyProduct(String productId) {
        for (Product p : products) {
            if (p.getId().equals(productId)) {
                products.remove(p);
                return "Producto comprado: " + p.getName();
            }
        }
        return "Producto no encontrado con ID: " + productId;
    }
}
