package es.sistemasdistribuidos;

import javax.xml.ws.Endpoint;
import es.sistemasdistribuidos.soap.StoreServiceImpl;

public class PublishStoreService {

    public static void main(String[] args) {
        String url = "http://localhost:8080/StoreService";
        Endpoint.publish(url, new StoreServiceImpl());
        System.out.println("Servicio StoreService publicado en: " + url);
    }
}
