package es.sistemasdistribuidos.soap;

import es.sistemasdistribuidos.model.Product;
import javax.jws.WebMethod;
import javax.jws.WebService;
import java.util.List;

@WebService
public interface StoreService {

    @WebMethod
    List<Product> getProducts();

    @WebMethod
    void addProduct(Product product);
    
    @WebMethod
    String buyProduct(String productId);

}
