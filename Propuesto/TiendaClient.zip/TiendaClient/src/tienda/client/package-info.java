@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.sistemasdistribuidos.es/")
package tienda.client;
