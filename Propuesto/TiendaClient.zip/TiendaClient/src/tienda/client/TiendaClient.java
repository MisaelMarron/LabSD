package tienda.client;

import java.util.List;
import java.util.Scanner;

public class TiendaClient {
    public static void main(String[] args) {
        StoreServiceImplService service = new StoreServiceImplService();
        StoreService port = service.getStoreServiceImplPort();

        Scanner scanner = new Scanner(System.in);

        // Mostrar productos disponibles
        List<Product> productos = port.getProducts();
        System.out.println("=== Productos disponibles ===");
        for (Product p : productos) {
            System.out.println(p.getId() + " - " + p.getName() + " - S/ " + p.getPrice());
        }

        // Pedir al usuario el ID del producto a comprar
        System.out.print("\nIngrese el ID del producto que desea comprar: ");
        String id = scanner.nextLine();

        // Llamar al servicio para comprar
        String resultado = port.buyProduct(id);
        System.out.println("\nResultado: " + resultado);

        // Mostrar productos restantes
        System.out.println("\n=== Productos restantes ===");
        for (Product p : port.getProducts()) {
            System.out.println(p.getId() + " - " + p.getName() + " - S/ " + p.getPrice());
        }

        scanner.close();
    }
}
