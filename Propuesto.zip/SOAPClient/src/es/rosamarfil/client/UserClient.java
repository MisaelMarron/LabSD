package es.rosamarfil.client;

import es.rosamarfil.soap.SOAPI;
import es.rosamarfil.soap.SOAPImplService;
import es.rosamarfil.soap.User;

import java.util.List;

public class UserClient {
    public static void main(String[] args) throws Exception {
        SOAPImplService service = new SOAPImplService();
        SOAPI port = service.getSOAPImplPort();

        System.out.println("Usuarios actuales:");
        List<User> users = port.getUsers();
        for (User u : users) {
            System.out.println(u.getName() + " (" + u.getUsername() + ")");
        }

        User nuevo = new User("Juan", "jperez");
        port.addUser(nuevo);

        System.out.println("Usuarios luego de agregar uno nuevo:");
        users = port.getUsers();
        for (User u : users) {
            System.out.println(u.getName() + " (" + u.getUsername() + ")");
        }
    }
}
