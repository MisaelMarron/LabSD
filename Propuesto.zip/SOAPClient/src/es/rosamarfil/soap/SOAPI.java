package es.rosamarfil.soap;

import java.util.List;
import javax.jws.WebService;

@WebService(targetNamespace = "http://soap.rosamarfil.es/", name = "SOAPI")
public interface SOAPI {
    List<User> getUsers();
    void addUser(User user);
}
