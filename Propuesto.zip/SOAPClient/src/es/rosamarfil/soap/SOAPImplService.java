package es.rosamarfil.soap;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

public class SOAPImplService extends Service {

    private final static QName SERVICE_NAME = new QName("http://soap.rosamarfil.es/", "SOAPImplService");

    public SOAPImplService() throws Exception {
        super(new URL("http://localhost:1516/WS/Users?wsdl"), SERVICE_NAME);
    }

    public SOAPI getSOAPImplPort() {
        return super.getPort(new QName("http://soap.rosamarfil.es/", "SOAPImplPort"), SOAPI.class);
    }
}
