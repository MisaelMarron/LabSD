@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.rosamarfil.es/")
package es.rosamarfil.soap;
